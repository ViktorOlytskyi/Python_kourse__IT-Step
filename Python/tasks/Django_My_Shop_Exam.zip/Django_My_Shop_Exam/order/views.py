import imaplib

from django.shortcuts import render, redirect

from django.contrib import messages
from .models import Product
from .forms import OrderForm
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import imaplib
import email.message
from cart.cart import Cart
from cart.forms import CartAddProductForm


def order(request):
    if 'order' in request.POST:
        name = request.POST.get('name')
        surname = request.POST.get('surname')
        phone = request.POST.get('phone')
        select = request.POST.get('select_v')
        city = request.POST.get('city')
        viddil = request.POST.get('viddil')
        post = ["Нова пошта","Укр пошта","Міст Експрес"]
        cart = Cart(request)
        text = "Всі поля мають бути заповнені!"
        mess = ""
        values = {'name':name, 'surname':surname, 'phone':phone, 'city':city, 'viddil':viddil}


        if name == "" or surname == "" or phone == "" or phone == "+380" or city == "" or viddil== "":
            mess = text
        if select == "виберіть...":
            mess = "Виберіть спосіб доставки!"
        if mess != "":
            return render(request, 'order/order.html', {'cart': cart, 'values':values, 'message': mess})
        else:
            # Налаштування з'єднання з сервером
            mail = imaplib.IMAP4_SSL('imap.ukr.net')
            mail.login('testshopitstep@ukr.net', 'rK6B2XcyVB0cFjP9')

            # Створення повідомлення
            msg = email.message.EmailMessage()
            msg['From'] = 'testshopitstep@ukr.net'
            msg['To'] = 'testshopitstep@ukr.net'
            msg['Subject'] = 'Нове замовлення!'
            body = f'Надійшло нове замовлення:\n\nПокупець: {name} {surname}\nТелефон: {phone}\n\nДані відправки:\nПошта:{post[int(select)]}\nМісто: {city}\nНомер відділення: {viddil}\n\n'
            body += 'Товари:\n'
            sum = 0
            for item in cart:
                body += f'{item["product"]} - {item["quantity"]}шт - {item["price"]} грн\n'


            body += f'\nВсього на суму: {cart.get_total_price()}'

            msg.set_content(body)

            # Відправлення повідомлення
            mail.append('INBOX', None, None, msg.as_bytes())
            mail.logout()
            cart.clear()
            return render(request, 'order/erder_accepted.html')

    else:
        cart = Cart(request)
        for item in cart:
            item['update_quantity_form'] = CartAddProductForm(initial={'quantity': item['quantity'],
                                                                       'update': True})
        return render(request, 'order/order.html', {'cart': cart, 'message':''})

