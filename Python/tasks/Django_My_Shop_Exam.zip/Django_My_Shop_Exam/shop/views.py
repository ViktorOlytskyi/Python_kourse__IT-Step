from django.shortcuts import render, get_object_or_404
from .models import Category, Product
from cart.forms import CartAddProductForm

def about(request):
    return render(request, "shop/about.html")
def delivery(request):
    return render(request, "shop/delivery.html")
def returning(request):
    return render(request, "shop/return.html")

def product_list(request, category_slug=None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)

    if 'filter'in request.GET:
        min_price = request.GET.get('min_price')
        max_price = request.GET.get('max_price')
        products_f = products.filter(price__range=(min_price, max_price))
        return render(request, "shop/product/list.html",
                      {
                          'category': category,
                          'categories': categories,
                          'products': products_f
                      })
    elif 'search'in request.GET:
        search = request.GET.get('search')
        lst_words = search.replace('.', '').split()
        products_ids_search = []
        prod = []
        for product in products:
            if  search == product.name:
                prod.append(product)
                return render(request, "shop/product/list.html",
                              {
                                  'category': category,
                                  'categories': categories,
                                  'products': prod
                              })

        for product in products:
            for word in lst_words:
                if word in product.name:
                    if product.id in products_ids_search:
                        continue
                    else:
                        products_ids_search.append(product.id)
        products_list = []
        for product in products:
            for id in products_ids_search:
                if id == product.id:
                    products_list.append(product)



        return render(request, "shop/product/list.html",
                      {
                          'category' : category,
                          'categories' : categories,
                          'products' : products_list
                      })
    else:
        if category_slug:
            category = get_object_or_404(Category, slug=category_slug)
            products = products.filter(category=category)

        return render(request, "shop/product/list.html",
                      {
                          'category' : category,
                          'categories' : categories,
                          'products' : products
                      })



def product_detail(request, id, slug):
    product = get_object_or_404(Product, id=id, slug=slug, available=True)
    add_to_cart = CartAddProductForm()
    return render(request, 'shop/product/detail.html', {'product' : product, 'add_to_cart' : add_to_cart})
# Create your views here.
